# Last-Man-Standing-Mini-Game
A web version of my board game - Last Man Standing -Ported from a board game concept to JavaScript HTML CSS

Website: [PLAY NOW](https://theslantedroom.github.io/Last-Man-Standing-Mini-Game/)

![Last man standing Image](https://raw.githubusercontent.com/theslantedroom/Last-Man-Standing-Mini-Game/main/img/githubLMS.jpg)

This is my first project where I explore JavaScript Html and CSS.  I have just started studying code and am using this to gain practical experience.   <br>
// this code is the first code I ever wrote, it was piled on top of itself with no plan or even knowledge of what was possible<br>
// its not very good code but I learned some things<br>
// to do;<br>
// clean this code up<br>
// make it look good<br>
//rewrite functions<br>
<br>  I will continue to develop this project possibly making it a stand alone app in 'Electron' or incorporating a back-end in Python or node.js for users to save their progress.
I plan to add in the campaign next, as present in the board game.

GOALS of this Project; <br>
 ~~Create 1v1 with static equipment and 1 enemy~~  <br>
 ~~ability to name character~~  <br>
 ~~choose different character cards~~  <br>
 ~~A market where you can buy equipment~~  <br>
 ~~ability to discard items~~  <br>
 ~~sort out the health bonus and max health systems~~  <br>
 ~~preview items in popup before purchase or discard~~  <br>
 ~~inventory system that prevents dual weilding two handed weapons~~  <br>
 ~~inventory system that prevents dual weilding shields~~  <br>
 ~~Skill cards that apply to battle calculations~~  <br>
 ~~add 34 enemy types using constructor function and class~~  <br>
 ~~add gold and healing systems~~  <br>
 add campaign <br>
 write music and code it in somehow <br>
 CSS and visual layout design <br>
 flesh out the animations and UI <br>
 possible stand alone app in phonegap or Electron <br>
 Look into backend for user data saving <br>

 
 

Please feel free to contact me with advise or suggestions.  <br>


- [The Slanted Room - My music stuff](https://www.theslantedroom.ca/)
- [steve@theslantedroom.ca](mailto:steve@theslantedroom.ca)
- [Wed Dev Portfolio](https://theslantedroom.github.io/steve.yee/)

